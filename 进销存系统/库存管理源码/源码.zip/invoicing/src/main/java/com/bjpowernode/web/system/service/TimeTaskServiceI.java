package com.bjpowernode.web.system.service;

import com.bjpowernode.core.common.service.CommonService;

public interface TimeTaskServiceI extends CommonService{

}
