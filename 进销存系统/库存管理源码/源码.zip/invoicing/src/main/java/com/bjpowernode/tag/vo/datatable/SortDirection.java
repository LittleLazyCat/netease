package com.bjpowernode.tag.vo.datatable;
/**
* @Description: TODO(排序定义) 
* asc 升序
* @author   
* desc 降序
*/
public enum SortDirection {
	asc, // 升序
	desc
	// 降序
}
