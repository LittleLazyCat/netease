package com.bjpowernode.web.system.service;

import com.bjpowernode.core.common.service.CommonService;

/**
 * 
 * @author   
 *
 */
public interface MenuInitService extends CommonService{
	
	public void initMenu();
}
