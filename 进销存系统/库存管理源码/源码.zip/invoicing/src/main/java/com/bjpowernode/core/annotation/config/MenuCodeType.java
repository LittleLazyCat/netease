package com.bjpowernode.core.annotation.config;

/**
 * 
 * @author   
 *
 */
public enum MenuCodeType {
	 TAG, //采用Jeecg tag标签 
	 ID,  //采用控件ID方式
	 CSS  //采用Css样式方式
}
