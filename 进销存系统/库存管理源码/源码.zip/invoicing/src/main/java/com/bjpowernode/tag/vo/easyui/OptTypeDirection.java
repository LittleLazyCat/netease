package com.bjpowernode.tag.vo.easyui;
/**
* 列表操作类型
* @author   
*/
public enum OptTypeDirection {
	Deff,Del,Fun,OpenWin,Confirm,ToolBar,OpenTab
	
}
