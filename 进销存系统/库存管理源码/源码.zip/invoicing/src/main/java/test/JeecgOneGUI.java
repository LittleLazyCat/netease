package test;

import org.jeecgframework.codegenerate.window.CodeWindow;


/**
 * 【单表模型】代码生成器入口
 * @author  
 *
 */
public class JeecgOneGUI{

	public static void main(String[] args) {
		CodeWindow  codeWindow = new CodeWindow();
		codeWindow.pack();
	}

}
